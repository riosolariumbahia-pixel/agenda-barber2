
export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="pt-br">
      <body style={{ background: "#000", color: "#fff", margin: 0 }}>
        {children}
      </body>
    </html>
  );
}
