
"use client";

import { useEffect, useState } from "react";
import { createClient } from "@supabase/supabase-js";

const supabase = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL!,
  process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!
);

export default function Home() {
  const [appointments, setAppointments] = useState<any[]>([]);

  useEffect(() => {
    load();
  }, []);

  async function load() {
    const { data } = await supabase.from("appointments").select("*");
    setAppointments(data || []);
  }

  return (
    <main style={{ padding: 20 }}>
      <h1>🔥 BarberFlow Pro</h1>
      <p>SaaS rodando na Vercel + Supabase</p>

      <div>
        {appointments.map(a => (
          <div key={a.id}>
            💰 R$ {a.price}
          </div>
        ))}
      </div>
    </main>
  );
}
