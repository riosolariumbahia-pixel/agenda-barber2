
# BarberFlow Pro ✅ (VERSÃO VALIDADA)

## Rodar local
npm install
npm run dev

## Deploy Vercel
1. Suba no GitHub
2. Importar na Vercel
3. Adicionar ENV
4. Deploy automático

SEM ERRO 404
SEM ERRO VITE
SEM ERRO NEXT
